import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart' show UltimateAgroTechApp, green;

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  String? error;
  String? role;
  String staffName = '';
  late final Stream<AuthState> _authStream;
  @override void initState() {
    super.initState();
    _authStream = Supabase.instance.client.auth.onAuthStateChange;
    _authStream.listen((_) => _loadProfile());
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() { role = null; staffName = ''; loading = false; error = null; });
      return;
    }
    try {
      final row = await Supabase.instance.client.from('staff_profiles').select('full_name,role,active').eq('id', user.id).single();
      if (row['active'] != true) {
        await Supabase.instance.client.auth.signOut();
        if (mounted) setState(() { loading = false; error = 'This staff account is inactive. Contact the Super Admin.'; });
        return;
      }
      final fetchedRole = row['role'] as String;
      if (!['super_admin','administrator','field_officer','sales_officer'].contains(fetchedRole)) {
        throw Exception('This account has an invalid staff role.');
      }
      if (mounted) setState(() { role = fetchedRole; staffName = (row['full_name'] as String?) ?? ''; loading = false; error = null; });
    } catch (e) {
      if (mounted) setState(() { loading = false; role = null; error = 'Could not verify staff access. Check your internet connection or ask the Super Admin to create your staff profile. Details: $e'; });
    }
  }

  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (role != null) return UltimateAgroTechApp(role: role!, staffName: staffName);
    return LoginPage(initialError: error, onLogin: _login);
  }

  Future<void> _login(String email, String password) async {
    setState(() { loading = true; error = null; });
    try {
      await Supabase.instance.client.auth.signInWithPassword(email: email.trim(), password: password);
      await _loadProfile();
    } on AuthException catch (e) {
      if (mounted) setState(() { loading = false; error = e.message; });
    } catch (e) {
      if (mounted) setState(() { loading = false; error = 'Login failed: $e'; });
    }
  }
}

class LoginPage extends StatefulWidget {
  final String? initialError;
  final Future<void> Function(String email, String password) onLogin;
  const LoginPage({super.key, this.initialError, required this.onLogin});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final form = GlobalKey<FormState>();
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false, hidePassword = true;
  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Form(key: form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Icon(Icons.agriculture, size: 68, color: green), const SizedBox(height: 12), const Text('ULTIMATE AGROTECH', textAlign: TextAlign.center, style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('Staff sign in • Shiga don shiga', textAlign: TextAlign.center), const SizedBox(height: 28),
    TextFormField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.username], decoration: const InputDecoration(labelText: 'Staff email', border: OutlineInputBorder(), prefixIcon: Icon(Icons.email)), validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid staff email' : null), const SizedBox(height: 12),
    TextFormField(controller: password, obscureText: hidePassword, autofillHints: const [AutofillHints.password], decoration: InputDecoration(labelText: 'Password', border: const OutlineInputBorder(), prefixIcon: const Icon(Icons.lock), suffixIcon: IconButton(onPressed: () => setState(() => hidePassword = !hidePassword), icon: Icon(hidePassword ? Icons.visibility : Icons.visibility_off))), validator: (v) => (v == null || v.isEmpty) ? 'Enter your password' : null), const SizedBox(height: 16),
    if (widget.initialError != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(widget.initialError!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
    FilledButton.icon(onPressed: busy ? null : () async { if (!form.currentState!.validate()) return; setState(() => busy = true); await widget.onLogin(email.text, password.text); if (mounted) setState(() => busy = false); }, icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.login), label: const Padding(padding: EdgeInsets.all(12), child: Text('Sign in / Shiga'))), const SizedBox(height: 12), const Text('Access is limited to staff accounts created by the Super Admin. Public self-registration is disabled.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
  ]))))));
}

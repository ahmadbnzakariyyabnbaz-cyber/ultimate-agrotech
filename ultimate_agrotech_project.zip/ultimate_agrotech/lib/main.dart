import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  final configured = url.startsWith('https://') && anonKey.isNotEmpty;
  if (configured) {
    await Supabase.initialize(url: url, anonKey: anonKey);
  }
  runApp(AgroBootstrap(configured: configured));
}

class AgroBootstrap extends StatelessWidget {
  final bool configured;
  const AgroBootstrap({super.key, required this.configured});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'ULTIMATE AGROTECH',
    theme: ThemeData(colorSchemeSeed: green, useMaterial3: true),
    home: configured ? const AuthGate() : const CloudSetupRequired(),
  );
}

class CloudSetupRequired extends StatelessWidget {
  const CloudSetupRequired({super.key});
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.cloud_off, size: 64), SizedBox(height: 16), Text('ULTIMATE AGROTECH', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), SizedBox(height: 12), Text('Cloud database has not been configured yet. Create a Supabase project, run docs/SUPABASE_SETUP.sql, then build with SUPABASE_URL and SUPABASE_ANON_KEY. Do not put a service-role key in this app.', textAlign: TextAlign.center)]))));
}

const green = Color(0xFF216B3A);
const hectareM2 = 10000.0;
const acreM2 = 4046.8564224;

String tr(bool en, String a, String b) => en ? a : b;
String naira(num n) => '₦${n.toStringAsFixed(2).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',')}';

class Farmer {
  final String id, name, phone, lga, village, crop;
  final DateTime createdAt;
  final List<Map<String, double>> points;
  final double areaM2;
  Farmer({required this.id, required this.name, required this.phone, required this.lga, required this.village, required this.crop, required this.createdAt, this.points = const [], this.areaM2 = 0});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'lga': lga, 'village': village, 'crop': crop, 'createdAt': createdAt.toIso8601String(), 'points': points, 'areaM2': areaM2};
  factory Farmer.fromJson(Map<String, dynamic> j) => Farmer(id: j['id'], name: j['name'], phone: j['phone'], lga: j['lga'], village: j['village'] ?? '', crop: j['crop'] ?? 'Maize', createdAt: DateTime.parse(j['createdAt']), points: (j['points'] as List? ?? []).map((p) => Map<String, double>.from((p as Map).map((k,v) => MapEntry(k.toString(), (v as num).toDouble())))).toList(), areaM2: (j['areaM2'] as num? ?? 0).toDouble());
}

class AgroStore extends ChangeNotifier {
  List<Farmer> farmers = [];
  Map<String, Map<String, double>> prices = {};
  Map<String, double> fertilizerPrices = {'NPK 15:15:15': 35000, 'NPK 20:10:10': 35000, 'NPK 12:12:17': 37000, 'Organic Fertilizer': 25000};
  Map<String, double> fertilizerRates = {'Maize': 200, 'Rice': 200, 'Millet': 150, 'Sorghum': 150, 'Wheat': 200, 'Potato': 250, 'Other': 200};
  bool english = true;
  bool loaded = false;
  String currentRole = 'field_officer';
  String staffName = '';
  bool cloudConnected = false;
  bool get canManagePrices => currentRole == 'super_admin' || currentRole == 'administrator';
  static const services = ['Ploughing', 'Harrowing', 'Planting', 'Leveling', 'Ridging', 'Harvesting'];
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    try { farmers = (jsonDecode(p.getString('farmers') ?? '[]') as List).map((e) => Farmer.fromJson(Map<String,dynamic>.from(e))).toList(); } catch (_) { farmers = []; }
    try { final raw = Map<String,dynamic>.from(jsonDecode(p.getString('prices') ?? '{}')); prices = raw.map((k,v) => MapEntry(k, Map<String,double>.from((v as Map).map((a,b) => MapEntry(a.toString(), (b as num).toDouble()))))); } catch (_) { prices = {}; }
    try { fertilizerPrices.addAll(Map<String,double>.from((jsonDecode(p.getString('fertilizerPrices') ?? '{}') as Map).map((k,v) => MapEntry(k.toString(), (v as num).toDouble())))); } catch (_) {}
    try { fertilizerRates.addAll(Map<String,double>.from((jsonDecode(p.getString('fertilizerRates') ?? '{}') as Map).map((k,v) => MapEntry(k.toString(), (v as num).toDouble())))); } catch (_) {}
    english = p.getBool('english') ?? true;
    // Pull shared records after login. If offline, keep the local cache available.
    try {
      final client = Supabase.instance.client;
      final rows = await client.from('farmers').select().order('created_at', ascending: false);
      final cloudFarmers = rows.map((r) => Farmer(
        id: r['farmer_code'] as String,
        name: r['full_name'] as String,
        phone: r['phone'] as String,
        lga: r['lga'] as String,
        village: (r['village'] as String?) ?? '',
        crop: (r['primary_crop'] as String?) ?? 'Maize',
        createdAt: DateTime.tryParse((r['created_at'] ?? '').toString()) ?? DateTime.now(),
        points: ((r['gps_points'] as List?) ?? []).map((pt) => Map<String,double>.from((pt as Map).map((k,v)=>MapEntry(k.toString(), (v as num).toDouble())))).toList(),
        areaM2: (r['area_m2'] as num? ?? 0).toDouble(),
      )).toList();
      final cloudIds = cloudFarmers.map((f) => f.id).toSet();
      // Retry locally cached farmer records that were created while offline.
      for (final local in farmers.where((f) => !cloudIds.contains(f.id))) {
        try { await _upsertFarmer(client, local); } catch (_) { /* retain local record for a later retry */ }
      }
      final merged = <String, Farmer>{for (final f in farmers) f.id: f};
      for (final f in cloudFarmers) { merged[f.id] = f; }
      farmers = merged.values.toList()..sort((a,b)=>b.createdAt.compareTo(a.createdAt));
      final priceRows = await client.from('service_prices').select('lga,service_code,price_ngn').isFilter('effective_to', null);
      for (final r in priceRows) {
        final l = (r['lga'] as String).toLowerCase();
        prices.putIfAbsent(l, () => {});
        prices[l][_serviceLabel(r['service_code'] as String)] = (r['price_ngn'] as num).toDouble();
      }
      final settings = await client.from('app_settings').select('setting_key,setting_value');
      for (final r in settings) {
        final key = r['setting_key']; final value = r['setting_value'];
        if (key == 'fertilizer_prices' && value is Map) fertilizerPrices.addAll(value.map((k,v)=>MapEntry(k.toString(), (v as num).toDouble())));
        if (key == 'fertilizer_rates' && value is Map) fertilizerRates.addAll(value.map((k,v)=>MapEntry(k.toString(), (v as num).toDouble())));
      }
      await p.setString('farmers', jsonEncode(farmers.map((f) => f.toJson()).toList()));
      cloudConnected = true;
    } catch (_) { cloudConnected = false; /* offline / cloud not configured: use local cache */ }
    loaded = true; notifyListeners();
  }
  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('farmers', jsonEncode(farmers.map((f) => f.toJson()).toList()));
    await p.setString('prices', jsonEncode(prices)); await p.setString('fertilizerPrices', jsonEncode(fertilizerPrices)); await p.setString('fertilizerRates', jsonEncode(fertilizerRates)); await p.setBool('english', english);
    notifyListeners();
  }
  String nextId() => 'UA-${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}';
  Future<void> _upsertFarmer(SupabaseClient client, Farmer f) async {
    await client.from('farmers').upsert({
      'farmer_code': f.id, 'full_name': f.name, 'phone': f.phone,
      'lga': f.lga, 'village': f.village, 'primary_crop': f.crop,
      'area_m2': f.areaM2, 'gps_points': f.points,
      'created_at': f.createdAt.toUtc().toIso8601String(),
    }, onConflict: 'farmer_code');
  }
  Future<bool> syncFarmer(Farmer f) async {
    try { await _upsertFarmer(Supabase.instance.client, f); cloudConnected = true; notifyListeners(); return true; }
    catch (_) { cloudConnected = false; notifyListeners(); return false; }
  }
  Future<bool> addFarmer(Farmer f) async {
    farmers.insert(0, f); await save();
    return syncFarmer(f);
  }
  Future<void> setPrice(String lga, String service, double price) async {
    prices.putIfAbsent(lga.trim().toLowerCase(), () => {}); prices[lga.trim().toLowerCase()]![service] = price; await save();
    final client = Supabase.instance.client;
    final code = _serviceCode(service);
    await client.from('service_prices').upsert({'lga': lga.trim(), 'service_code': code, 'unit': 'hectare', 'price_ngn': price, 'effective_to': null}, onConflict: 'lga,service_code');
  }
  Future<void> pushFertilizerSettings() async {
    final client = Supabase.instance.client;
    await client.from('app_settings').upsert({'setting_key':'fertilizer_prices','setting_value':fertilizerPrices});
    await client.from('app_settings').upsert({'setting_key':'fertilizer_rates','setting_value':fertilizerRates});
  }
  String _serviceCode(String service) => service.toLowerCase().replaceAll(' ', '_');
  String _serviceLabel(String code) => code.split('_').map((w)=>w.isEmpty?w:'${w[0].toUpperCase()}${w.substring(1)}').join(' ');
  double servicePrice(String lga, String service) => prices[lga.trim().toLowerCase()]?[service] ?? 0;
}

class UltimateAgroTechApp extends StatefulWidget { final String role; final String staffName; const UltimateAgroTechApp({super.key, required this.role, required this.staffName}); @override State<UltimateAgroTechApp> createState() => _UltimateAgroTechAppState(); }
class _UltimateAgroTechAppState extends State<UltimateAgroTechApp> {
  final store = AgroStore();
  @override void initState() { super.initState(); store.currentRole = widget.role; store.staffName = widget.staffName; store.load(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_,__) => MaterialApp(debugShowCheckedModeBanner: false, title: 'ULTIMATE AGROTECH', theme: ThemeData(colorSchemeSeed: green, useMaterial3: true), home: store.loaded ? HomeScreen(store: store) : const Scaffold(body: Center(child: CircularProgressIndicator())));
}

class HomeScreen extends StatefulWidget { final AgroStore store; const HomeScreen({super.key, required this.store}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final s = widget.store; final en = s.english;
    final pages = [Dashboard(store: s, go: (i) => setState(() => index = (i == 5 && !s.canManagePrices) ? 0 : i)), FarmerPage(store: s), AreaAndGpsPage(store: s), MechanizationPage(store: s), FertilizerPage(store: s), s.canManagePrices ? PricePage(store: s) : const Center(child: Text('Only administrators can manage prices.'))];
    final labels = [tr(en,'Home','Gida'),tr(en,'Farmers','Manoma'),tr(en,'Farm area','Girman gona'),tr(en,'Services','Ayyuka'),tr(en,'Fertilizer','Taki'),tr(en,'Prices','Farashi')];
    return Scaffold(appBar: AppBar(title: const Text('ULTIMATE AGROTECH', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), actions: [IconButton(tooltip: 'Sign out', icon: const Icon(Icons.logout), onPressed: () async { await Supabase.instance.client.auth.signOut(); }), PopupMenuButton<bool>(icon: const Icon(Icons.language), tooltip: 'Language / Harshe', onSelected: (v) async { s.english = v; await s.save(); }, itemBuilder: (_) => const [PopupMenuItem(value: true, child: Text('English')), PopupMenuItem(value: false, child: Text('Hausa'))])]), body: pages[index], bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: [for (int i=0;i<labels.length;i++) NavigationDestination(icon: Icon([Icons.dashboard_outlined,Icons.people_outline,Icons.map_outlined,Icons.agriculture,Icons.grass,Icons.price_change_outlined][i]), selectedIcon: Icon([Icons.dashboard,Icons.people,Icons.map,Icons.agriculture,Icons.grass,Icons.price_change][i]), label: labels[i]) ]));
  }
}

class Dashboard extends StatelessWidget { final AgroStore store; final ValueChanged<int> go; const Dashboard({super.key, required this.store, required this.go});
  @override Widget build(BuildContext context) { final en=store.english; return ListView(padding: const EdgeInsets.all(16), children: [Card(color: Theme.of(context).colorScheme.primaryContainer, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ULTIMATE AGROTECH', style: Theme.of(context).textTheme.headlineSmall), const SizedBox(height: 8), Text('Ultimate Fertiliser and Agro-Chemical'), Text(tr(en,'In collaboration with Jigawa State Farm Mechanization Service Company Ltd.','A hadin gwiwa da Jigawa State Farm Mechanization Service Company Ltd.'))]))), const SizedBox(height: 12), Wrap(spacing: 10, runSpacing: 10, children: [_stat(context,tr(en,'Farmers','Manoma'),'${store.farmers.length}',Icons.people),_stat(context,tr(en,'Mapped farms','Gonaki masu area'),'${store.farmers.where((f)=>f.areaM2>0).length}',Icons.landscape),_stat(context,tr(en,'Farm area total','Jimillar girman gona'),'${(store.farmers.fold<double>(0,(a,f)=>a+f.areaM2)/hectareM2).toStringAsFixed(2)} ha',Icons.square_foot),_stat(context,tr(en,'Services','Ayyukan noma'),'6',Icons.agriculture)]), const SizedBox(height: 18), Text(tr(en,'Quick actions','Ayyuka masu sauri'),style: Theme.of(context).textTheme.titleLarge), for (final a in [(tr(en,'Register farmer','Yi wa manomi rajista'),1,Icons.person_add),(tr(en,'Measure farm / GPS','Auna gona / GPS'),2,Icons.gps_fixed),(tr(en,'Mechanization quotation','Lissafin kuɗin ayyukan noma'),3,Icons.agriculture),(tr(en,'Fertilizer calculator','Lissafin takin zamani'),4,Icons.grass),(tr(en,'Edit LGA prices','Gyara farashin LGA'),5,Icons.edit_note)]) Card(child: ListTile(leading: Icon(a.$3),title: Text(a.$1),trailing: const Icon(Icons.chevron_right),onTap:()=>go(a.$2))), const SizedBox(height: 12), Text((store.cloudConnected ? 'Cloud status: Connected • Signed in as ${store.staffName} (${store.currentRole}).' : 'Cloud status: Offline / not synced. New records remain on this device until connection is restored.'),style: Theme.of(context).textTheme.bodySmall)]); }
  Widget _stat(BuildContext c,String title,String value,IconData icon)=>SizedBox(width:MediaQuery.of(c).size.width/2-24,child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon),const SizedBox(height:8),Text(value,style:Theme.of(c).textTheme.headlineSmall),Text(title)]))));
}

class FarmerPage extends StatefulWidget { final AgroStore store; const FarmerPage({super.key,required this.store}); @override State<FarmerPage> createState()=>_FarmerPageState(); }
class _FarmerPageState extends State<FarmerPage> {
 final keyForm=GlobalKey<FormState>(); final name=TextEditingController(),phone=TextEditingController(),lga=TextEditingController(),village=TextEditingController(); String crop='Maize';
 @override void dispose(){name.dispose();phone.dispose();lga.dispose();village.dispose();super.dispose();}
 @override Widget build(BuildContext context){final en=widget.store.english;return ListView(padding:const EdgeInsets.all(16),children:[Text(tr(en,'Register farmer','Rajistar manomi'),style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),Form(key:keyForm,child:Column(children:[_input(name,tr(en,'Full name *','Cikakken suna *'),Icons.person),_input(phone,tr(en,'Phone number *','Lambar waya *'),Icons.phone,keyboard:TextInputType.phone),_input(lga,tr(en,'Local Government Area (LGA) *','Ƙaramar hukuma *'),Icons.location_city),_input(village,tr(en,'Village / community','Ƙauye / al’umma'),Icons.home_work,required:false),DropdownButtonFormField<String>(value:crop,decoration:InputDecoration(labelText:tr(en,'Main crop','Amfanin gona'),border:const OutlineInputBorder()),items:const ['Maize','Rice','Millet','Sorghum','Wheat','Potato','Other'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>crop=v??crop)),const SizedBox(height:14),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()async{if(!keyForm.currentState!.validate())return;final f=Farmer(id:widget.store.nextId(),name:name.text.trim(),phone:phone.text.trim(),lga:lga.text.trim(),village:village.text.trim(),crop:crop,createdAt:DateTime.now());final synced = await widget.store.addFarmer(f);name.clear();phone.clear();lga.clear();village.clear();if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${synced ? tr(en,'Farmer saved to cloud. ID:','An ajiye manomi a database. ID:') : tr(en,'Saved on this phone only; cloud sync failed. ID:','An ajiye a waya kawai; sync bai yi nasara ba. ID:')} ${f.id}')));},icon:const Icon(Icons.save),label:Text(tr(en,'Save farmer','Ajiye manomi'))))])),const Divider(height:28),Text('${tr(en,'Registered farmers','Manoman da aka yi rajista')}: ${widget.store.farmers.length}',style:Theme.of(context).textTheme.titleMedium),for(final f in widget.store.farmers) Card(child:ListTile(leading:CircleAvatar(child:Text(f.name.isEmpty?'?':f.name[0].toUpperCase())),title:Text(f.name),subtitle:Text('${f.id} • ${f.phone}\n${f.village.isEmpty?'': '${f.village}, '}${f.lga} • ${f.crop}\n${f.areaM2>0?'${(f.areaM2/hectareM2).toStringAsFixed(3)} ha':''}'),isThreeLine:true,trailing:const Icon(Icons.verified_user_outlined))) ]);}
 Widget _input(TextEditingController c,String label,IconData icon,{TextInputType? keyboard,bool required=true})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(controller:c,keyboardType:keyboard,validator:(v)=>required&&(v==null||v.trim().isEmpty)?'Required / Ana buƙata':null,decoration:InputDecoration(labelText:label,prefixIcon:Icon(icon),border:const OutlineInputBorder())));
}

class AreaAndGpsPage extends StatefulWidget { final AgroStore store; const AreaAndGpsPage({super.key,required this.store}); @override State<AreaAndGpsPage> createState()=>_AreaAndGpsPageState(); }
class _AreaAndGpsPageState extends State<AreaAndGpsPage>{final length=TextEditingController(),width=TextEditingController();String? farmerId;double? area;bool tracking=false,busy=false;final List<Position> points=[];String status='';
 @override void dispose(){length.dispose();width.dispose();super.dispose();}
 double polygonArea(List<Position> ps){if(ps.length<3)return 0;final lat0=ps.fold<double>(0,(a,p)=>a+p.latitude)/ps.length*math.pi/180;final xy=ps.map((p)=>(x:p.longitude*111320*math.cos(lat0*math.pi/180),y:p.latitude*110540)).toList();double sum=0;for(var i=0;i<xy.length;i++){final j=(i+1)%xy.length;sum+=xy[i].x*xy[j].y-xy[j].x*xy[i].y;}return sum.abs()/2;}
 Future<void> gpsPoint() async {setState(()=>busy=true);try{bool enabled=await Geolocator.isLocationServiceEnabled();if(!enabled)throw Exception('Turn on phone location / Kunna GPS na waya');LocationPermission perm=await Geolocator.checkPermission();if(perm==LocationPermission.denied)perm=await Geolocator.requestPermission();if(perm==LocationPermission.denied||perm==LocationPermission.deniedForever)throw Exception('Location permission required / Ana buƙatar izinin GPS');final p=await Geolocator.getCurrentPosition(locationSettings:const LocationSettings(accuracy:LocationAccuracy.best));setState(()=>points.add(p));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> saveGpsFarm()async{if(farmerId==null||points.length<3){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Choose a farmer and record at least 3 boundary points.')));return;}final a=polygonArea(points);final i=widget.store.farmers.indexWhere((f)=>f.id==farmerId);if(i<0)return;final old=widget.store.farmers[i];final updated=Farmer(id:old.id,name:old.name,phone:old.phone,lga:old.lga,village:old.village,crop:old.crop,createdAt:old.createdAt,points:points.map((p)=>{'lat':p.latitude,'lng':p.longitude}).toList(),areaM2:a);widget.store.farmers[i]=updated;await widget.store.save();final synced=await widget.store.syncFarmer(updated);setState((){area=a;tracking=false;status=synced?'Farm boundary saved to cloud.':'Farm boundary saved on this phone; cloud sync failed.';});}
 @override Widget build(BuildContext context){final en=widget.store.english;return ListView(padding:const EdgeInsets.all(16),children:[Text(tr(en,'Farm measurement & GPS boundary','Auna gona da GPS'),style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:8),const Text('Rectangular dimensions: area = length × width. GPS: walk around the farm boundary and record points at corners; at least 3 points are required.'),const SizedBox(height:14),DropdownButtonFormField<String>(value:farmerId,decoration:const InputDecoration(labelText:'Select registered farmer',border:OutlineInputBorder()),items:widget.store.farmers.map((f)=>DropdownMenuItem(value:f.id,child:Text('${f.name} (${f.id})'))).toList(),onChanged:(v)=>setState(()=>farmerId=v)),const SizedBox(height:18),Text(tr(en,'Manual dimensions','Auna ta tsawo da faɗi'),style:Theme.of(context).textTheme.titleMedium),const SizedBox(height:8),TextField(controller:length,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Length (metres) / Tsawo',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:width,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Width (metres) / Faɗi',border:OutlineInputBorder())),const SizedBox(height:10),FilledButton(onPressed:(){final l=double.tryParse(length.text),w=double.tryParse(width.text);if(l==null||w==null||l<=0||w<=0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter valid positive dimensions.')));return;}final measured=l*w;setState(()=>area=measured);if(farmerId!=null){final i=widget.store.farmers.indexWhere((f)=>f.id==farmerId);if(i>=0){final old=widget.store.farmers[i];final updated=Farmer(id:old.id,name:old.name,phone:old.phone,lga:old.lga,village:old.village,crop:old.crop,createdAt:old.createdAt,points:old.points,areaM2:measured);widget.store.farmers[i]=updated;widget.store.save().then((_){widget.store.syncFarmer(updated);});}}},child:const Text('Calculate manual area')),const SizedBox(height:8),if(area!=null)_areaCard(area!),const Divider(height:28),Text(tr(en,'GPS boundary walk','Auna iyakar gona da GPS'),style:Theme.of(context).textTheme.titleMedium),Text('Recorded points: ${points.length}'),if(points.isNotEmpty)Text('Latest: ${points.last.latitude.toStringAsFixed(6)}, ${points.last.longitude.toStringAsFixed(6)} • accuracy ${points.last.accuracy.toStringAsFixed(1)} m'),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:[FilledButton.icon(onPressed:busy?null:gpsPoint,icon:busy?const SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.add_location_alt),label:const Text('Record GPS point')),OutlinedButton(onPressed:points.isEmpty?null:()=>setState(()=>points.clear()),child:const Text('Clear points')),FilledButton.icon(onPressed:saveGpsFarm,icon:const Icon(Icons.save),label:const Text('Save GPS farm'))]),if(points.length>=3)_areaCard(polygonArea(points)),if(status.isNotEmpty)Text(status),const SizedBox(height:10),const Text('GPS area uses a local planar approximation and phone GPS accuracy can vary. For official land measurement, confirm boundaries and verify the result on site.')]);}
 Widget _areaCard(double a)=>Card(color:Theme.of(context).colorScheme.primaryContainer,child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${a.toStringAsFixed(2)} m²',style:Theme.of(context).textTheme.headlineSmall),Text('${(a/hectareM2).toStringAsFixed(4)} hectares'),Text('${(a/acreM2).toStringAsFixed(4)} acres')])));
}

class MechanizationPage extends StatefulWidget{final AgroStore store;const MechanizationPage({super.key,required this.store});@override State<MechanizationPage> createState()=>_MechanizationPageState();}
class _MechanizationPageState extends State<MechanizationPage>{final lga=TextEditingController();final ha=TextEditingController(text:'1');final selected=<String>{};@override void dispose(){lga.dispose();ha.dispose();super.dispose();}@override Widget build(BuildContext context){final s=widget.store;final area=double.tryParse(ha.text)??0;final total=selected.fold<double>(0,(a,k)=>a+s.servicePrice(lga.text,k)*area);return ListView(padding:const EdgeInsets.all(16),children:[Text('Mechanization quotation / Lissafin ayyukan noma',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),TextField(controller:lga,decoration:const InputDecoration(labelText:'LGA / Ƙaramar hukuma',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:10),TextField(controller:ha,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Farm area (hectares)',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:12),Text('Select services / Zaɓi ayyuka',style:Theme.of(context).textTheme.titleMedium),for(final service in AgroStore.services)CheckboxListTile(value:selected.contains(service),title:Text(service),subtitle:Text('${naira(s.servicePrice(lga.text,service))} / hectare'),onChanged:(v)=>setState(()=>v==true?selected.add(service):selected.remove(service))),Card(color:Theme.of(context).colorScheme.primaryContainer,child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Estimated total / Jimillar kuɗi',style:TextStyle(fontWeight:FontWeight.bold)),Text(naira(total),style:Theme.of(context).textTheme.headlineMedium),const Text('Only prices configured for this LGA are included. Set approved prices in the Prices tab.')]))]);}}

class FertilizerPage extends StatefulWidget{final AgroStore store;const FertilizerPage({super.key,required this.store});@override State<FertilizerPage> createState()=>_FertilizerPageState();}
class _FertilizerPageState extends State<FertilizerPage>{String crop='Maize',product='NPK 15:15:15';final ha=TextEditingController(text:'1');final bag=TextEditingController(text:'50');@override void dispose(){ha.dispose();bag.dispose();super.dispose();}@override Widget build(BuildContext context){final s=widget.store;final area=double.tryParse(ha.text)??0,bagKg=double.tryParse(bag.text)??50;final kg=area*(s.fertilizerRates[crop]??0);final bags=bagKg>0?kg/bagKg:0;final price=s.fertilizerPrices[product]??0;final exact=price*bags;final whole=price*bags.ceil();return ListView(padding:const EdgeInsets.all(16),children:[Text('Fertilizer calculator / Lissafin takin zamani',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),DropdownButtonFormField<String>(value:crop,decoration:const InputDecoration(labelText:'Crop / Amfanin gona',border:OutlineInputBorder()),items:s.fertilizerRates.keys.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>crop=v??crop)),const SizedBox(height:10),DropdownButtonFormField<String>(value:product,decoration:const InputDecoration(labelText:'Fertilizer product / Nau’in taki',border:OutlineInputBorder()),items:s.fertilizerPrices.keys.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>product=v??product)),const SizedBox(height:10),TextField(controller:ha,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Farm area (hectares)',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:10),TextField(controller:bag,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Bag weight (kg)',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:12),Card(color:Theme.of(context).colorScheme.primaryContainer,child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Configured rate: ${(s.fertilizerRates[crop]??0).toStringAsFixed(1)} kg/ha'),Text('Required fertilizer: ${kg.toStringAsFixed(2)} kg',style:Theme.of(context).textTheme.titleLarge),Text('Exact bag equivalent: ${bags.toStringAsFixed(2)}'),Text('Whole bags to buy: ${bags.ceil()}'),Text('Product price per bag: ${naira(price)}'),Text('Pro-rated cost: ${naira(exact)}'),Text('Whole-bag purchase cost: ${naira(whole)}',style:Theme.of(context).textTheme.titleMedium)])),const SizedBox(height:10),const Text('IMPORTANT: sample application rates and prices are placeholders. An agronomist must approve crop/product rates before operational use.')]);}}

class PricePage extends StatefulWidget{final AgroStore store;const PricePage({super.key,required this.store});@override State<PricePage> createState()=>_PricePageState();}
class _PricePageState extends State<PricePage>{final lga=TextEditingController(text:'Hadejia');final controllers=<String,TextEditingController>{for(final x in AgroStore.services)x:TextEditingController()};final fertilizerControllers=<String,TextEditingController>{'NPK 15:15:15':TextEditingController(),'NPK 20:10:10':TextEditingController(),'NPK 12:12:17':TextEditingController(),'Organic Fertilizer':TextEditingController()};final rateControllers=<String,TextEditingController>{for(final x in ['Maize','Rice','Millet','Sorghum','Wheat','Potato','Other'])x:TextEditingController()};@override void dispose(){lga.dispose();for(final c in controllers.values)c.dispose();for(final c in fertilizerControllers.values)c.dispose();for(final c in rateControllers.values)c.dispose();super.dispose();}@override Widget build(BuildContext context){final s=widget.store;for(final e in controllers.entries){if(e.value.text.isEmpty){final p=s.servicePrice(lga.text,e.key);if(p>0)e.value.text=p.toStringAsFixed(0);}}for(final e in fertilizerControllers.entries){if(e.value.text.isEmpty)e.value.text=(s.fertilizerPrices[e.key]??0).toStringAsFixed(0);}for(final e in rateControllers.entries){if(e.value.text.isEmpty)e.value.text=(s.fertilizerRates[e.key]??0).toStringAsFixed(0);}return ListView(padding:const EdgeInsets.all(16),children:[Text('Price management / Gudanar da farashi',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:8),const Text('Example prices are not confirmed company prices. Configure approved values for each LGA.'),const SizedBox(height:12),TextField(controller:lga,decoration:const InputDecoration(labelText:'LGA / Ƙaramar hukuma',border:OutlineInputBorder()),),const SizedBox(height:12),Text('Mechanization services (₦/ha)',style:Theme.of(context).textTheme.titleMedium),for(final e in controllers.entries)Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:e.value,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:e.key,border:const OutlineInputBorder(),prefixText:'₦ '))),Text('Fertilizer prices (₦/bag)',style:Theme.of(context).textTheme.titleMedium),for(final e in fertilizerControllers.entries)Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:e.value,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:e.key,border:const OutlineInputBorder(),prefixText:'₦ '))),Text('Application rate (kg/hectare)',style:Theme.of(context).textTheme.titleMedium),for(final e in rateControllers.entries)Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:e.value,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:e.key,border:const OutlineInputBorder()))),FilledButton.icon(onPressed:()async{double parse(TextEditingController c)=>double.tryParse(c.text.trim())??-1;final invalid=[...controllers.values,...fertilizerControllers.values,...rateControllers.values].any((c)=>parse(c)<0);if(lga.text.trim().isEmpty||invalid){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid LGA and non-negative numeric values.')));return;}try{for(final e in controllers.entries){await s.setPrice(lga.text,e.key,parse(e.value));}s.fertilizerPrices.updateAll((k,v)=>parse(fertilizerControllers[k]!));s.fertilizerRates.updateAll((k,v)=>parse(rateControllers[k]!));await s.save();await s.pushFertilizerSettings();if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Prices and rates saved to cloud.')));}catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Cloud save failed. Check connection and admin role. Error: $e')));}},icon:const Icon(Icons.save),label:const Text('Save price settings'))]);}}

#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${SUPABASE_URL:-}" || -z "${SUPABASE_ANON_KEY:-}" ]]; then
  echo "Set SUPABASE_URL and SUPABASE_ANON_KEY first. Do not use a service-role key." >&2
  echo "Example: export SUPABASE_URL='https://YOUR_PROJECT.supabase.co'" >&2
  echo "         export SUPABASE_ANON_KEY='YOUR_PUBLIC_ANON_KEY'" >&2
  exit 2
fi

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK was not found. Install Flutter and Android Studio first." >&2
  exit 2
fi

cd "$(dirname "$0")/.."
if [[ ! -d android ]]; then
  flutter create . --platforms=android
fi

MANIFEST="android/app/src/main/AndroidManifest.xml"
if [[ -f "$MANIFEST" ]]; then
  python3 - "$MANIFEST" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text()
marker='<manifest '
permissions='''    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
'''
if 'android.permission.INTERNET' not in s:
    i=s.find('>')
    if i >= 0: s=s[:i+1]+'\n'+permissions+s[i+1:]
p.write_text(s)
PY
fi

flutter pub get
flutter test
flutter build apk --release \
  --dart-define="SUPABASE_URL=${SUPABASE_URL}" \
  --dart-define="SUPABASE_ANON_KEY=${SUPABASE_ANON_KEY}"
echo "APK ready: build/app/outputs/flutter-apk/app-release.apk"

import 'package:flutter_test/flutter_test.dart';
import 'package:ultimate_agrotech/main.dart' as app;

void main() {
  test('farm area conversion constants are correct', () {
    expect(app.hectareM2, 10000.0);
    expect(app.acreM2, closeTo(4046.8564, 0.001));
  });
}

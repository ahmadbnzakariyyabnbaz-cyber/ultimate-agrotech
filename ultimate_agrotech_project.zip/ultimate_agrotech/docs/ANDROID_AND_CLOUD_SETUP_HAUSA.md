# ULTIMATE AGROTECH — Haɗa Cloud da gina Android APK

## Abubuwan da dole ne su kasance
1. Asusun Supabase da sabon project (database na intanet).
2. Project URL da anon/publishable key daga Project Settings > API.
3. Flutter SDK da Android SDK (Android Studio) a kwamfutar da za a gina APK.
4. Email/password na Super Admin da za a ƙirƙira a Supabase Authentication.

**Ba a saka service-role key a cikin app ba.** Kada a tura password ko service-role key cikin ZIP, GitHub, ko cikin manhajar wayar.

## Mataki na 1 — ƙirƙiri cloud database
- Ƙirƙiri project a Supabase.
- Buɗe SQL Editor.
- Kwafa duk abin da ke `docs/SUPABASE_SETUP.sql`, sannan ka Run.
- Je Authentication > Users, ƙirƙiri user na Super Admin.
- Kwafa UUID na user ɗin, sannan ka maye gurbin UUID a umarnin `insert into public.staff_profiles...` da ke ƙarshen SQL.
- Gudanar da umarnin INSERT ɗin a SQL Editor.
- Ƙirƙiri sauran ma'aikata a Authentication > Users; saka profile dinsu a `staff_profiles` da role ɗin da ya dace.

## Mataki na 2 — gina APK
A kwamfuta mai Flutter da Android Studio:

```bash
cd ultimate_agrotech
flutter create . --platforms=android
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

Script ɗin yana ƙara Internet da GPS permissions a Android manifest. APK ɗin zai kasance a:
`build/app/outputs/flutter-apk/app-release.apk`

A maye gurbin `YOUR_PROJECT` da `YOUR_SUPABASE_ANON_KEY` da bayanan project ɗinka. Anon/publishable key na app yana da kariya ne ta RLS policies; kada a yi amfani da service-role key.

## Muhimman bayanai da har yanzu ake buƙatar tabbatarwa
- Wannan muhalli ba shi da Flutter/Android SDK kuma ba shi da damar intanet don sauke su; saboda haka ba a iya compile ko gwada APK a nan.
- Ba a ba da Supabase project URL/key ko damar shiga asusun ba; saboda haka ba a iya ƙirƙira cloud project ɗin kai tsaye daga wannan zaman.
- An shirya Flutter source domin login, role check, cloud read/write na rajistar manoma, da sync na farashi/settings. Duk da haka, cikakken offline queue/automatic retry, cikakken UI na stock/sales/receipts, reset password, da gwajin tsaro a kan ainihin project suna buƙatar ƙarin aiwatarwa kafin amfani na kasuwanci.
- Farashin taki da application rates a seed ɗin misalai ne kawai; a canza su zuwa farashin kamfani da ƙimar da ƙwararren agronomist ya amince da su.
- Ka fara da gwaji da bayanan ƙarya kafin saka ainihin bayanan manoma.

## Idan ba ka da kwamfuta: gina APK ta GitHub Actions
An saka `.github/workflows/build-apk.yml` domin a iya gina APK a GitHub cloud, amma kana buƙatar GitHub account:
1. Ƙirƙiri sabon private repository a GitHub.
2. Upload/extract dukkan fayilolin wannan project a repository, har da `.github` folder.
3. A repository: Settings > Secrets and variables > Actions > New repository secret.
4. Ƙirƙiri `SUPABASE_URL` da `SUPABASE_ANON_KEY` (public anon/publishable key kawai; ba service-role key ba).
5. Je Actions > Build ULTIMATE AGROTECH APK > Run workflow.
6. Idan build ya yi nasara, buɗe run ɗin sannan ka sauke artifact mai suna `ultimate-agrotech-android-apk`. Cikin artifact ɗin akwai `app-release.apk`.

Idan ba a ƙirƙiri Supabase project da staff profile ba, APK zai iya ginuwa amma ba za a iya shiga ko amfani da shared database ba.

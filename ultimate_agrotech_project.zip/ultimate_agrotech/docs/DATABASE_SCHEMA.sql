-- Ultimate AgroTech proposed PostgreSQL + PostGIS schema
-- Apply only after review in a secure hosted database. Never put database admin keys in the mobile app.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE staff_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('super_admin','administrator','field_officer','sales_officer')),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE farmers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_code TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  state_name TEXT NOT NULL DEFAULT 'Jigawa',
  lga TEXT NOT NULL,
  village TEXT,
  primary_crop TEXT,
  created_by UUID REFERENCES staff_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE farms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL REFERENCES farmers(id) ON DELETE CASCADE,
  farm_name TEXT,
  lga TEXT NOT NULL,
  village TEXT,
  boundary GEOMETRY(Polygon, 4326),
  area_m2 NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (area_m2 >= 0),
  area_hectares NUMERIC(12,6) GENERATED ALWAYS AS (area_m2 / 10000.0) STORED,
  area_acres NUMERIC(12,6) GENERATED ALWAYS AS (area_m2 / 4046.8564224) STORED,
  measurement_method TEXT NOT NULL CHECK (measurement_method IN ('gps_boundary','manual_dimensions','survey_import')),
  gps_accuracy_m NUMERIC(8,2),
  measured_by UUID REFERENCES staff_users(id),
  measured_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE service_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lga TEXT NOT NULL,
  service_code TEXT NOT NULL CHECK (service_code IN ('ploughing','harrowing','planting','leveling','ridging','harvesting','spraying','threshing')),
  unit TEXT NOT NULL DEFAULT 'hectare' CHECK (unit IN ('hectare','acre','farm','hour')),
  price_ngn NUMERIC(14,2) NOT NULL CHECK (price_ngn >= 0),
  effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_to TIMESTAMPTZ,
  updated_by UUID REFERENCES staff_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE fertilizer_products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_name TEXT NOT NULL,
  product_type TEXT NOT NULL CHECK (product_type IN ('NPK','organic','other')),
  bag_weight_kg NUMERIC(8,2) NOT NULL DEFAULT 50 CHECK (bag_weight_kg > 0),
  sale_price_per_bag NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (sale_price_per_bag >= 0),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE fertilizer_rate_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  crop_name TEXT NOT NULL,
  product_id UUID NOT NULL REFERENCES fertilizer_products(id),
  rate_kg_per_hectare NUMERIC(10,2) NOT NULL CHECK (rate_kg_per_hectare >= 0),
  guidance_note TEXT,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_to TIMESTAMPTZ,
  updated_by UUID REFERENCES staff_users(id)
);

CREATE TABLE mechanization_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL REFERENCES farmers(id),
  farm_id UUID NOT NULL REFERENCES farms(id),
  lga TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'quoted' CHECK (status IN ('quoted','approved','scheduled','in_progress','completed','cancelled')),
  quotation_number TEXT UNIQUE NOT NULL,
  total_ngn NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_by UUID REFERENCES staff_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE mechanization_job_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES mechanization_jobs(id) ON DELETE CASCADE,
  service_code TEXT NOT NULL,
  area_hectares NUMERIC(12,6) NOT NULL CHECK (area_hectares >= 0),
  unit_price_ngn NUMERIC(14,2) NOT NULL CHECK (unit_price_ngn >= 0),
  line_total_ngn NUMERIC(14,2) NOT NULL CHECK (line_total_ngn >= 0)
);

CREATE TABLE inventory_movements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES fertilizer_products(id),
  movement_type TEXT NOT NULL CHECK (movement_type IN ('stock_in','sale','adjustment','return')),
  bags NUMERIC(12,2) NOT NULL,
  reference TEXT,
  recorded_by UUID REFERENCES staff_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID REFERENCES farmers(id),
  receipt_number TEXT UNIQUE NOT NULL,
  subtotal_ngn NUMERIC(14,2) NOT NULL DEFAULT 0,
  paid_ngn NUMERIC(14,2) NOT NULL DEFAULT 0,
  balance_ngn NUMERIC(14,2) GENERATED ALWAYS AS (subtotal_ngn - paid_ngn) STORED,
  recorded_by UUID REFERENCES staff_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sale_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES fertilizer_products(id),
  bags NUMERIC(12,2) NOT NULL CHECK (bags > 0),
  unit_price_ngn NUMERIC(14,2) NOT NULL CHECK (unit_price_ngn >= 0),
  line_total_ngn NUMERIC(14,2) NOT NULL CHECK (line_total_ngn >= 0)
);

CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES staff_users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX farms_boundary_gix ON farms USING GIST(boundary);
CREATE INDEX farmers_lga_idx ON farmers(lga);
CREATE INDEX farms_farmer_idx ON farms(farmer_id);
CREATE INDEX jobs_created_idx ON mechanization_jobs(created_at);

-- ULTIMATE AGROTECH cloud database (Supabase PostgreSQL)
-- Run this whole file in Supabase Dashboard > SQL Editor using the project owner account.
-- The mobile app must use ONLY the Project URL + anon/publishable key. Never use service_role in the app.

create extension if not exists pgcrypto;

create table if not exists public.staff_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('super_admin','administrator','field_officer','sales_officer')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.farmers (
  id uuid primary key default gen_random_uuid(),
  farmer_code text unique not null,
  full_name text not null,
  phone text not null,
  state_name text not null default 'Jigawa',
  lga text not null,
  village text not null default '',
  primary_crop text not null default 'Maize',
  area_m2 numeric(14,2) not null default 0 check (area_m2 >= 0),
  gps_points jsonb not null default '[]'::jsonb,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.service_prices (
  id uuid primary key default gen_random_uuid(),
  lga text not null,
  service_code text not null check (service_code in ('ploughing','harrowing','planting','leveling','ridging','harvesting')),
  unit text not null default 'hectare' check (unit in ('hectare','acre','farm','hour')),
  price_ngn numeric(14,2) not null check (price_ngn >= 0),
  effective_to timestamptz,
  updated_by uuid default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  unique (lga, service_code)
);

create table if not exists public.app_settings (
  setting_key text primary key,
  setting_value jsonb not null,
  updated_by uuid default auth.uid() references auth.users(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.farms (
  id uuid primary key default gen_random_uuid(),
  farmer_code text not null references public.farmers(farmer_code) on delete cascade,
  farm_name text not null default '',
  lga text not null,
  village text not null default '',
  area_m2 numeric(14,2) not null default 0 check (area_m2 >= 0),
  gps_points jsonb not null default '[]'::jsonb,
  measurement_method text not null check (measurement_method in ('gps_boundary','manual_dimensions','survey_import')),
  gps_accuracy_m numeric(8,2),
  measured_by uuid default auth.uid() references auth.users(id),
  measured_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.fertilizer_products (
  id uuid primary key default gen_random_uuid(),
  product_name text unique not null,
  product_type text not null check (product_type in ('NPK','organic','other')),
  bag_weight_kg numeric(8,2) not null default 50 check (bag_weight_kg > 0),
  sale_price_per_bag numeric(14,2) not null default 0 check (sale_price_per_bag >= 0),
  stock_bags numeric(12,2) not null default 0 check (stock_bags >= 0),
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.fertilizer_rate_rules (
  id uuid primary key default gen_random_uuid(),
  crop_name text not null,
  product_id uuid not null references public.fertilizer_products(id),
  rate_kg_per_hectare numeric(10,2) not null check (rate_kg_per_hectare >= 0),
  guidance_note text,
  updated_by uuid default auth.uid() references auth.users(id),
  unique (crop_name, product_id)
);

create table if not exists public.mechanization_jobs (
  id uuid primary key default gen_random_uuid(),
  farmer_code text not null references public.farmers(farmer_code),
  lga text not null,
  status text not null default 'quoted' check (status in ('quoted','approved','scheduled','in_progress','completed','cancelled')),
  quotation_number text unique not null,
  total_ngn numeric(14,2) not null default 0 check (total_ngn >= 0),
  created_by uuid default auth.uid() references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.mechanization_job_lines (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.mechanization_jobs(id) on delete cascade,
  service_code text not null,
  area_hectares numeric(12,6) not null check (area_hectares >= 0),
  unit_price_ngn numeric(14,2) not null check (unit_price_ngn >= 0),
  line_total_ngn numeric(14,2) not null check (line_total_ngn >= 0)
);

create table if not exists public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.fertilizer_products(id),
  movement_type text not null check (movement_type in ('stock_in','sale','adjustment','return')),
  bags numeric(12,2) not null check (bags <> 0),
  reference text,
  recorded_by uuid default auth.uid() references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  farmer_code text references public.farmers(farmer_code),
  receipt_number text unique not null,
  subtotal_ngn numeric(14,2) not null default 0 check (subtotal_ngn >= 0),
  paid_ngn numeric(14,2) not null default 0 check (paid_ngn >= 0 and paid_ngn <= subtotal_ngn),
  recorded_by uuid default auth.uid() references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.sale_lines (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid not null references public.fertilizer_products(id),
  bags numeric(12,2) not null check (bags > 0),
  unit_price_ngn numeric(14,2) not null check (unit_price_ngn >= 0),
  line_total_ngn numeric(14,2) not null check (line_total_ngn >= 0)
);

create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid default auth.uid() references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists farmers_lga_idx on public.farmers(lga);
create index if not exists farms_farmer_code_idx on public.farms(farmer_code);
create index if not exists jobs_created_idx on public.mechanization_jobs(created_at);
create index if not exists sales_created_idx on public.sales(created_at);

create or replace function public.current_staff_role()
returns text language sql stable security definer set search_path = public
as $$ select role from public.staff_profiles where id = auth.uid() and active = true limit 1 $$;

create or replace function public.is_active_staff()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.staff_profiles where id = auth.uid() and active = true) $$;

alter table public.staff_profiles enable row level security;
alter table public.farmers enable row level security;
alter table public.service_prices enable row level security;
alter table public.app_settings enable row level security;
alter table public.farms enable row level security;
alter table public.fertilizer_products enable row level security;
alter table public.fertilizer_rate_rules enable row level security;
alter table public.mechanization_jobs enable row level security;
alter table public.mechanization_job_lines enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.sales enable row level security;
alter table public.sale_lines enable row level security;
alter table public.audit_log enable row level security;

-- Profiles: staff can see only their own role; administrators manage all staff through a trusted admin workflow.
drop policy if exists staff_profiles_read_self on public.staff_profiles;
create policy staff_profiles_read_self on public.staff_profiles for select to authenticated using (id = auth.uid() or public.current_staff_role() in ('super_admin','administrator'));
drop policy if exists staff_profiles_admin_update on public.staff_profiles;
create policy staff_profiles_admin_update on public.staff_profiles for update to authenticated using (public.current_staff_role() = 'super_admin') with check (public.current_staff_role() = 'super_admin');

-- Farmer data: only active staff. Field officers and admins can create/update; deletion is admin-only.
drop policy if exists farmers_staff_select on public.farmers;
create policy farmers_staff_select on public.farmers for select to authenticated using (public.is_active_staff());
drop policy if exists farmers_staff_insert on public.farmers;
create policy farmers_staff_insert on public.farmers for insert to authenticated with check (public.is_active_staff() and created_by = auth.uid());
drop policy if exists farmers_staff_update on public.farmers;
create policy farmers_staff_update on public.farmers for update to authenticated using (public.current_staff_role() in ('super_admin','administrator','field_officer')) with check (public.current_staff_role() in ('super_admin','administrator','field_officer'));
drop policy if exists farmers_admin_delete on public.farmers;
create policy farmers_admin_delete on public.farmers for delete to authenticated using (public.current_staff_role() in ('super_admin','administrator'));

-- Prices/settings: readable by all active staff, writable by admins only.
drop policy if exists service_prices_staff_select on public.service_prices;
create policy service_prices_staff_select on public.service_prices for select to authenticated using (public.is_active_staff());
drop policy if exists service_prices_admin_write on public.service_prices;
create policy service_prices_admin_write on public.service_prices for all to authenticated using (public.current_staff_role() in ('super_admin','administrator')) with check (public.current_staff_role() in ('super_admin','administrator'));
drop policy if exists app_settings_staff_select on public.app_settings;
create policy app_settings_staff_select on public.app_settings for select to authenticated using (public.is_active_staff());
drop policy if exists app_settings_admin_write on public.app_settings;
create policy app_settings_admin_write on public.app_settings for all to authenticated using (public.current_staff_role() in ('super_admin','administrator')) with check (public.current_staff_role() in ('super_admin','administrator'));

-- Remaining operational tables: active staff can read; writes are limited to administrators, field officers, or sales staff as appropriate.
create policy farms_staff_all on public.farms for all to authenticated using (public.is_active_staff()) with check (public.is_active_staff());
create policy fertilizer_products_staff_read on public.fertilizer_products for select to authenticated using (public.is_active_staff());
create policy fertilizer_products_admin_write on public.fertilizer_products for all to authenticated using (public.current_staff_role() in ('super_admin','administrator')) with check (public.current_staff_role() in ('super_admin','administrator'));
create policy fertilizer_rates_staff_read on public.fertilizer_rate_rules for select to authenticated using (public.is_active_staff());
create policy fertilizer_rates_admin_write on public.fertilizer_rate_rules for all to authenticated using (public.current_staff_role() in ('super_admin','administrator')) with check (public.current_staff_role() in ('super_admin','administrator'));
create policy jobs_staff_read on public.mechanization_jobs for select to authenticated using (public.is_active_staff());
create policy jobs_staff_insert on public.mechanization_jobs for insert to authenticated with check (public.current_staff_role() in ('super_admin','administrator','field_officer'));
create policy jobs_admin_update on public.mechanization_jobs for update to authenticated using (public.current_staff_role() in ('super_admin','administrator')) with check (public.current_staff_role() in ('super_admin','administrator'));
create policy job_lines_staff_all on public.mechanization_job_lines for all to authenticated using (public.is_active_staff()) with check (public.is_active_staff());
create policy inventory_staff_read on public.inventory_movements for select to authenticated using (public.is_active_staff());
create policy inventory_sales_write on public.inventory_movements for insert to authenticated with check (public.current_staff_role() in ('super_admin','administrator','sales_officer'));
create policy sales_staff_read on public.sales for select to authenticated using (public.is_active_staff());
create policy sales_sales_write on public.sales for insert to authenticated with check (public.current_staff_role() in ('super_admin','administrator','sales_officer'));
create policy sale_lines_staff_read on public.sale_lines for select to authenticated using (public.is_active_staff());
create policy sale_lines_sales_write on public.sale_lines for insert to authenticated with check (public.current_staff_role() in ('super_admin','administrator','sales_officer'));
create policy audit_staff_read on public.audit_log for select to authenticated using (public.current_staff_role() in ('super_admin','administrator'));
create policy audit_staff_insert on public.audit_log for insert to authenticated with check (public.is_active_staff() and actor_id = auth.uid());

-- Seed editable product catalogue and editable example settings. Verify prices/rates before real use.
insert into public.fertilizer_products (product_name, product_type, bag_weight_kg, sale_price_per_bag)
values ('NPK 15:15:15','NPK',50,35000),('NPK 20:10:10','NPK',50,35000),('NPK 12:12:17','NPK',50,37000),('Organic Fertilizer','organic',50,25000)
on conflict (product_name) do nothing;
insert into public.app_settings(setting_key,setting_value)
values ('fertilizer_prices','{"NPK 15:15:15":35000,"NPK 20:10:10":35000,"NPK 12:12:17":37000,"Organic Fertilizer":25000}'::jsonb),
       ('fertilizer_rates','{"Maize":200,"Rice":200,"Millet":150,"Sorghum":150,"Wheat":200,"Potato":250,"Other":200}'::jsonb)
on conflict (setting_key) do nothing;

-- FIRST SUPER ADMIN SETUP:
-- 1. Create the first user in Supabase Dashboard > Authentication > Users (email + temporary password).
-- 2. Copy that user's UUID and run this separately, replacing values:
-- insert into public.staff_profiles(id, full_name, role, active)
-- values ('PASTE-AUTH-USER-UUID-HERE', 'Super Admin', 'super_admin', true);
-- 3. Create other staff users in Authentication > Users and insert their profile with the right role.

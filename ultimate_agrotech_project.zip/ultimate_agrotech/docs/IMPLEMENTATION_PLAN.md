# ULTIMATE AGROTECH — status and implementation plan

## Agreed scope
- Product: ULTIMATE AGROTECH.
- Organizations: Ultimate Fertiliser and Agro-Chemical in collaboration with Jigawa State Farm Mechanization Service Company Ltd.
- Android-first; English and Hausa planned.
- Staff-only farmer registration.
- Roles: Super Admin, Administrator, Field Officer and Sales Officer.
- Farm area in m², hectares and acres, measured manually or using GPS boundary points.
- Services: ploughing, harrowing, planting, leveling, ridging and harvesting.
- Editable prices by LGA; fertilizer product prices and crop-specific application-rate settings.
- Fertilizer sales, inventory, payments, receipts, reporting and offline operation are part of the target scope.

## Current files
- Flutter prototype in `lib/main.dart`.
- Proposed PostgreSQL/PostGIS schema in `docs/DATABASE_SCHEMA.sql`.
- Interactive responsive browser demo in `web_demo/index.html`.

## Current implementation status
The Flutter prototype includes local farmer registration, generated IDs, local device storage, manual area calculations, GPS point capture with a simple polygon approximation, LGA-specific service pricing, and a fertilizer calculator. The browser demo additionally provides a more complete local demonstration of stock movements, fertilizer sales, balances, CSV export and JSON backup/restore.

**Neither prototype is a production release.** Flutter SDK was not available in this environment, so no APK was compiled and the Flutter code was not verified with `flutter analyze` or on a physical device. The web demo's records remain in the browser's local storage and are not shared or protected by server authentication.

## Production roadmap
1. Install Flutter and Android SDK; generate Android platform files; run package resolution, static analysis, automated tests and device tests.
2. Deploy a secure API and PostgreSQL/PostGIS backend. Store credentials server-side only.
3. Implement login, password reset, role-based authorization, audit logs and admin account setup.
4. Implement reliable offline-first synchronization, duplicate prevention, conflict resolution and sync indicators.
5. Implement backend-authoritative farmer, farm, price, quotation, service-job, stock, sale and payment records.
6. Snapshot the effective LGA price and fertilizer rule on each quotation/sale; retain history when rates change.
7. Add PDF/Excel reports, receipt printing/sharing, scheduled backups and restore tests.
8. Validate farm boundary measurements on known test plots and show GPS accuracy to users.
9. Replace sample prices and fertilizer rates with company-approved values; agronomist approves agronomic rules.
10. Perform security/privacy review, field acceptance testing, configure Android signing, build APK/AAB and prepare rollout/training.

## Operational cautions
- 1 hectare = 10,000 m²; 1 acre ≈ 4,046.856 m².
- Phone GPS can be inaccurate; do not treat these estimates as legal survey measurements.
- Do not enter sensitive real farmer records into the demo until access control, backups and privacy controls are ready.
- Example prices and application rates are placeholders only.

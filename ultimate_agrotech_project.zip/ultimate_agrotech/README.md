# ULTIMATE AGROTECH

Android-first Flutter app for Ultimate Fertiliser and Agro-Chemical, in collaboration with Jigawa State Farm Mechanization Service Company Ltd.

## Included
- Flutter Android source (not a prebuilt APK)
- English/Hausa language option
- Staff sign-in with roles: Super Admin, Administrator, Field Officer, Sales Officer
- Cloud-ready Supabase/PostgreSQL setup with row-level security policies
- Farmer registration, unique farmer ID, LGA/village/crop, area and GPS points
- Farm area calculations (m², hectares, acres) and GPS boundary capture
- Mechanization quotation calculator with LGA-specific prices
- Fertilizer calculator for NPK 15:15:15, NPK 20:10:10, NPK 12:12:17 and organic fertilizer
- Editable fertilizer prices and example crop application rates
- Local cache and basic retry of locally saved farmer records when the app next starts online
- Responsive browser demo retained in `web_demo/` for preview only

## Important current status
**No APK is included yet.** This environment does not have Flutter/Android SDK installed and cannot download them. There is also no Supabase project URL/key or account access in this session, so the cloud database has been prepared as SQL but has not been deployed to a live project.

The Flutter source has not been compiled or tested with `flutter analyze`, automated tests, or a physical Android device. The current cloud integration covers staff authentication, farmer records/GPS fields, service prices, and fertilizer settings. The cloud schema includes inventory/sales/job tables, but complete stock/sales/receipt screens and robust background/offline synchronization still need implementation and testing before commercial production use.

## Cloud database setup
1. Create a Supabase project.
2. Open SQL Editor and run all of `docs/SUPABASE_SETUP.sql`.
3. Create a user under Authentication > Users.
4. Insert a matching row into `staff_profiles` with role `super_admin`, following the commented example at the bottom of the SQL file.
5. Create each staff user and add their profile with the correct role.

Never put a Supabase service-role key in the Android app. Use only the project URL and anon/publishable key with the SQL's RLS policies enabled.

## Build Android APK (Linux/macOS)
Install Flutter and Android Studio/SDK, then from the project root:

```bash
export SUPABASE_URL='https://YOUR_PROJECT.supabase.co'
export SUPABASE_ANON_KEY='YOUR_PUBLIC_ANON_KEY'
./scripts/build_android.sh
```

The build script generates the Android platform files if needed, adds Internet/location permissions, resolves dependencies, runs analysis/tests, and attempts a release build. Output path:
`build/app/outputs/flutter-apk/app-release.apk`

For the detailed Hausa guide, see `docs/ANDROID_AND_CLOUD_SETUP_HAUSA.md`.

## Before operational use
- Replace sample fertilizer prices and application rates with approved company values.
- Have an agronomist approve crop-specific fertilizer rates.
- Test RLS and all roles with separate staff accounts.
- Add complete sales, inventory, receipt, reports, account recovery, and robust offline sync flows.
- Test GPS area results on known farms; phone GPS is not a legal land survey.
- Review privacy, backups, access logs, and Android release signing.

## Build without installing Android SDK locally
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Upload this project to a private GitHub repository, add repository secrets named `SUPABASE_URL` and `SUPABASE_ANON_KEY`, then run **Actions > Build ULTIMATE AGROTECH APK > Run workflow**. Download the resulting `ultimate-agrotech-android-apk` artifact. This still requires the cloud database to be set up first.
